package com.gmail.fishing.village;

import org.aiwolf.common.data.Player;

import java.util.*;

public class ResultsStore {
    private ArrayList<Player> modelList;
    private Map<Player, Map<TYPE, Integer>> cntMap;
    public int numGame;

    public ResultsStore(ArrayList<Player> modelList) {
        this.cntMap = new HashMap<>();
        this.modelList = modelList;
        this.numGame = 0;
        // init hashmap; all 0 padding.
        modelList.stream().forEach(p -> {
            cntMap.put(p, new HashMap<>());
            cntMap.get(p).put(TYPE.SEL, 0);
            cntMap.get(p).put(TYPE.WON, 0);
        });
    }

    public void onWon(Player p) {
        int w = cntMap.get(p).get(TYPE.WON);
        cntMap.get(p).put(TYPE.WON, w + 1);
    }
    
    public void onSelected(Player p) {
        int s = cntMap.get(p).get(TYPE.SEL);
        cntMap.get(p).put(TYPE.SEL, s + 1);

    }

    public Player getChampion() {
        ArrayList<Player> champStock = new ArrayList<>();
        Player champ = null;
        float maxRatio = 0.0f;
        float r = 0;

        for(Player p: modelList){
            float sel = (float)this.getModelInfo(p).get(TYPE.SEL);
            float won = (float)this.getModelInfo(p).get(TYPE.WON);
            r = sel == 0 ? 0 : won / sel;
            if (r == maxRatio) {
                champStock.add(p);
            }
            else if (r > maxRatio) {
                try {
                    champStock.clear();
                }
                catch (NullPointerException e) {
                    System.out.println(e);
                }
                champStock.add(p);
                maxRatio = r;
            }
        }
        if (champStock == null) {
            champ = modelList.get(new Random().nextInt(modelList.size()));
        } else {
            champ = champStock.get(new Random().nextInt(champStock.size()));
        }
        return champ;
    }

    public Player getLoser() {
        Player loser = modelList.get(new Random().nextInt(modelList.size()));
        float min_ratio = 2.0f;
        for(Player p: cntMap.keySet()){
            float r = cntMap.get(p).get(TYPE.SEL) == 0 ? 0 : cntMap.get(p).get(TYPE.WON) / cntMap.get(p).get(TYPE.SEL);
            if (r < min_ratio) {
                min_ratio = r;
                loser = p;
            }
        }
        if (loser == null) {
            loser = modelList.get(new Random().nextInt(modelList.size()));
        }
        return loser;
    }

    public Map<TYPE, Integer> getModelInfo(Player p) {
        return cntMap.get(p);
    }

    public enum TYPE {
        WON,
        SEL
    }

}