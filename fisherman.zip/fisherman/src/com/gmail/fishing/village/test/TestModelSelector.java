package com.gmail.fishing.village.test;

import com.gmail.fishing.village.ModelSelector;
import com.gmail.fishing.village.ResultsStore;
import com.gmail.fishing.village.cedec2017impl.LightPlayer;
import org.aiwolf.common.data.Player;
import org.aiwolf.common.data.Team;
import org.aiwolf.sample.player.SampleRoleAssignPlayer;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;



public class TestModelSelector {


    public TestModelSelector() {
    }

    public static void main(String[] args) throws IOException {
        // #of game
        int N = 100;
        // set model
        ArrayList<Player> modelList = new ArrayList<>();


        modelList.add(new LightPlayer());
        modelList.add(new SampleRoleAssignPlayer());


        // set selector and store
        ResultsStore store    = new ResultsStore(modelList);
        ModelSelector selectr = new ModelSelector(modelList, store);



        // file IO
        FileWriter fwriter = null;
        try{
            File file = new File("/path");

            fwriter = new FileWriter(file);

        }catch(IOException e){
            System.out.println(e);
        }

        // config winning rate for each models.
        HashMap<Player, Float> rateMap = new HashMap<>();
        rateMap.put(modelList.get(0), 0.5f);

        // start pseudo game
        for (int i=0; i<N; i++) {
            //float epsilon = 1.0f / (float) Math.log(store.numGame + 1 + 0.00001) - 0.1f;
            //Player myAgent = selectr.greedyEpsilonSelect(epsilon);
            //Player myAgent = selectr.ucb1Select();
            //Player myAgent = selectr.abTestSelect(10);
            Player myAgent = selectr.readConfigSelect();
            store.onSelected(myAgent);
            float r = new Random().nextFloat();
            if (r < rateMap.get(myAgent)) {
                // when won the game
                store.onWon(myAgent);
            }
            Map m = store.getModelInfo(myAgent);
            System.out.println(i + " " + myAgent.getName());
            try {
                fwriter.write(i + " " + myAgent.getName() +"\n");

            }catch(NullPointerException e){
                System.out.println(e);
            }
            store.numGame++;
            //System.out.println(i + " " + store.getChampion().getName() + " " + r);
        }
        fwriter.close();
        // print log
        for (Player p: modelList ) {
            Map m = store.getModelInfo(p);
            System.out.println(p.getName() + m.get(ResultsStore.TYPE.WON) + "/" + m.get(ResultsStore.TYPE.SEL));



        }


    }

}
