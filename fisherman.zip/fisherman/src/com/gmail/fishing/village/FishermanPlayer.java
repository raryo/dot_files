package com.gmail.fishing.village;


import org.aiwolf.common.data.Agent;
import org.aiwolf.common.data.Player;
import org.aiwolf.common.data.Role;
import org.aiwolf.common.data.Team;
import org.aiwolf.common.net.GameInfo;
import org.aiwolf.common.net.GameSetting;

import java.util.ArrayList;
import java.util.Map;

public class FishermanPlayer implements Player {

    private Player myAgent;
    // List of instances of model
    private ArrayList<Player> modelList = new ArrayList<>(2);
    private ModelSelector selectr = null;
    private ResultsStore  store   = null;
    private boolean isInit  = true;
    private GameInfo gi;
    private Utils util = new Utils();

    /**
     * コンストラクタ
     * initialize() が呼ばれるタイミングで、
     * selectr, store など100回の間はデータを
     * 保持してもらいたいものについては、nullかどうか
     * ＝新しいセットかどうか判断して適宜初期。
     *
     */
    public FishermanPlayer() {    }

    /**
     * 新しいセットが始まる1ゲーム目のinitialize で呼ばれる。
     * 伝説のエージェントを召喚（インスタンス化）して、
     * modelList にセットする。
     * また、selectr, store を準備する。
     */
    private void setModelList() {
        // Player1
        Player player1 = new RoleAssignPlayer();
        // Player2
        Player player2  = new RoleAssignPlayer2();
        modelList.add(player1);
        modelList.add(player2);

        if (store == null) {
            store = new ResultsStore(modelList);
        }
        if (selectr == null) {
            selectr = new ModelSelector(modelList, store);
        }
        isInit = false;
    }

    @Override
    public String getName() {
        return "fisherman";
    }



    /**
     * initializer .
     * 各ゲームの最初に呼ばれる。セットの最初のゲームではsetModelList が呼ばれる
     * ここで、エージェントの割り当てを行う。
     *
     * アレンジとしては、デフォルトモデルを無しにして、greedySelectのε（探索
     * （ランダムにチョイス）する確率）をいじることが挙げられる。
     *
     * 単純に大きくしたり小さくしたり。or動的にしても良い。デフォルトモデル自体を
     * greedyで選んでみるのも良いかもしれない。
     * 
     */
    @Override
    public void initialize(GameInfo gameInfo, GameSetting gameSetting) {

        if (isInit) {         // セットの初期化
            this.setModelList();
            myAgent = modelList.get(0);
        }else {
            /**
             * ε-Greedy
             */
            // 動的εの例
            //float epsilon = 1.0f / (float) Math.log(store.numGame + 1 + 0.00001) - 0.15f;
            // 静的εの例
            float epsilon = 0.2f;
            myAgent = selectr.greedyEpsilonSelect(epsilon);


            /**
             * A/B test
             */
            //myAgent = selectr.abTestSelect(15);

            /**
             * UCB1 select
             */
            //myAgent = selectr.ucb1Select();

            /**
             * read from file mode
             *
             */
             //myAgent = selectr.readConfigSelect();
        }
        if (myAgent == null){
            myAgent = modelList.get(0);
        }
        modelList.stream().forEach(m -> m.initialize(gameInfo, gameSetting));

        // モデルが選ばれた数を数える。
        store.onSelected(myAgent);
    }

    @Override
    public void update(GameInfo gameInfo) {
        this.gi = gameInfo;
        modelList.stream().forEach(m -> m.update(gameInfo));
    }

    @Override
    public void dayStart() {
        modelList.stream().forEach(m -> m.dayStart());
    }

    @Override
    public String talk() {
        String ret = myAgent.talk();
        return ret;
    }

    @Override
    public String whisper() {
        String ret = myAgent.whisper();
        return ret;
    }

    @Override
    public Agent vote() {
        Agent ret = myAgent.vote();
        return ret;
    }

    @Override
    public Agent attack() {
        Agent ret = myAgent.attack();
        return ret;
    }

    @Override
    public Agent divine() {
        Agent ret =  myAgent.divine();
        return ret;
    }

    @Override
    public Agent guard() {
        Agent ret = myAgent.guard();
        return ret;
    }

    /**
     * finish 
     * 終了処理。ゲームの最後に呼ばれる。
     */

    @Override
    public void finish() {
        // count #of games.
        store.numGame++;
        // count #of won.
        if (isWon(gi.getRole().getTeam())){
            store.onWon(myAgent);
        }
        // call model's original finish() method.
        //modelList.stream().forEach(m -> m.finish());
        modelList.stream().forEach(m -> m.finish());

        // DEBUG
        /**
        System.out.println("<============GAME END===========>\n");
        modelList.stream().forEach(p -> {
            Map m = store.getModelInfo(p);
            util.printlog(p.getName() + ": " +
                    m.get(ResultsStore.TYPE.WON) + "/" +
                    m.get(ResultsStore.TYPE.SEL));
        });
        util.printlog("#of GAME: " + store.numGame);*/
    }

    public boolean isWon(Team t) {
        ArrayList<Role> aliveRoleList = new ArrayList<Role>();
        gi.getAliveAgentList().stream().forEach(q ->
                aliveRoleList.add(gi.getRoleMap().get(q))
        );
        boolean isWWAlive = aliveRoleList.contains(Role.WEREWOLF); // True: WW won, false: VLL won
        Team wonTeam = isWWAlive? Team.WEREWOLF : Team.VILLAGER;
        return t == wonTeam;
    }


}
