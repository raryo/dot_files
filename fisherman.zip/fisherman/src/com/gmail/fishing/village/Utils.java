package com.gmail.fishing.village;

public class Utils {

    public Utils() {

    }

    public void printlog(String str) {
        System.out.println("SSS:" + str);
    }
}
