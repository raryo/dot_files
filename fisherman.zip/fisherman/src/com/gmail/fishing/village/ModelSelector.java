package com.gmail.fishing.village;

import org.aiwolf.common.data.Player;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

public class ModelSelector {
    private ArrayList<Player> modelList;
    private ResultsStore store;

    public ModelSelector(ArrayList<Player> modelList, ResultsStore store){
        this.modelList = modelList;
        this.store = store;
    }

    public Player randomSelect() {
        Random rand = new Random();
        Player p = modelList.get(rand.nextInt(modelList.size()));
        return p;
    }


    /**
     *
     *
     * method id
     * 0: random
     * 1: e-greedy
     * 2: A/B
     * 3: UCB1
     *
     */
    public Player readConfigSelect() {
        Player p = null;
        int selectionMethod = 0;
        String arg = "0.0";

        try {
            // read file
            FileInputStream fileInputStream = new FileInputStream("/Users/zhenzhen/works/aiwolf/library/AIWolf-ver0.5.6/exp_data/config.json");
            byte[] buffer = new byte[fileInputStream.available()];
            fileInputStream.read(buffer);
            fileInputStream.close();

            // parse string to JSON
            String json = new String(buffer);
            JSONObject jsonObj= new JSONObject(json);
            selectionMethod = jsonObj.getInt("Method");
            arg = jsonObj.get("arg").toString();
        } catch (Exception e) {
            System.out.println(e);
        }

        switch (selectionMethod) {
            case 0:
                p = this.randomSelect();
                break;
            case 1:
                p = this.greedyEpsilonSelect(Float.parseFloat(arg));
                break;
            case 2:
                p = this.abTestSelect(Integer.parseInt(arg));
                break;
            case 3:
                p = this.ucb1Select();
                break;
        }
        if (p == null) {
            p = this.greedyEpsilonSelect(0.15f);
        }
        return p;
    }


    /**
     * Epsilon greedy algorithm
     *
     *
     * e is \epsilon, which decide take random arm (explore; probability e), or
     * take max mean arm (exploit)
     */
    public Player greedyEpsilonSelect(float e) {
        Player bestP;
        Random rand = new Random();
        float r = rand.nextFloat();
        if (r < e) {
            bestP = randomSelect();
        } else {
            // exploit, choice
            bestP = store.getChampion();
        }
        return bestP;
    }

    // Users set default player instead of random select.
    public Player greedyEpsilonSelect(float e, Player p) {
        Player bestP;
        Random rand = new Random();
        float r = rand.nextFloat();
        if (r < e) {
            bestP = randomSelect();
        } else {
            // exploit, choice
            bestP = p;
        }
        return bestP;
    }


    /**
     * UCB1 ; Upper Confidential Boundary Algorithm
     *
     * UCB1 select an arm which have max UCB score, which E[arm_i] + (Chernoff-Hoeffding bound), considering
     * confidentiality of arm's E.
     */
    public Player ucb1Select () {
        // ucb score list
        //HashMap<Player, Float> ucbMap= new HashMap<>();
        int t = store.numGame;
        Player bestP = null;
        float max_ucb = 0.0f;
        for (Player p: modelList) {
            Map<ResultsStore.TYPE, Integer> m = store.getModelInfo(p);
            float sel = (float)m.get(ResultsStore.TYPE.SEL);
            float won = (float)m.get(ResultsStore.TYPE.WON);
            if (sel == 0) {
                bestP = p;
                break;
            } else {
                float ucb = won / sel + (float)Math.sqrt( 2 * Math.log(t) / sel);
                if (ucb > max_ucb) {
                    bestP = p;
                    max_ucb = ucb;
                }
                //System.out.println(p.getName() + " " + ucb);
            }
        }
        if (bestP == null) {
            bestP = randomSelect();
        }
        return bestP;
    }

    /**
     * A/B test
     *
     * A/B use fixed time to explore, before exploit phase.
     * e.g. using first of 20 games to explore i.e. random sampling,
     *      and then using rest of N-20 games to exploit; pure greedy algorithm.
     */
    public Player abTestSelect (int exploreNumberOfGamesPerModel) {
        int n = exploreNumberOfGamesPerModel;
        Player p = null;

        // exploring phase.
        if (store.numGame < n * modelList.size()) {
            ArrayList<Player> exploreList = new ArrayList<>();
            // find models witch must be sampled.
            modelList.stream().forEach(m -> {
                if (store.getModelInfo(m).get(ResultsStore.TYPE.SEL) < n) {
                    exploreList.add(m);
                }
            });
            //System.out.println("rest: " + exploreList.size());
            p = exploreList.get(new Random().nextInt(exploreList.size()));
        }
        // exploit
        if (p == null) {
            p = store.getChampion();
        }
        return p;
    }


}

